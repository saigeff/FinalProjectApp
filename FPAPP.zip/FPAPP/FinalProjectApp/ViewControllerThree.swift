//
//  ViewControllerThree.swift
//  FInalProjectApp
//
//  Created by Saige Forbes on 7/31/21.
//
//THERE IS AN ERROR WITH THIS VC AND VC THREE WHERE THE EDITS APPEAR ON BOTH SCREENS - SAIGE

import UIKit

class ViewControllerThree: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
  
    @IBAction func englishPressed(_ sender: UIButton) {
    }
    
    @IBAction func chinesePressed(_ sender: UIButton) {
    }
    
    @IBAction func spanishPressed(_ sender: UIButton) {
    }
    
    @IBAction func frenchPressed(_ sender: UIButton) {
    }
    
    @IBAction func koreanPressed(_ sender: UIButton) {
    }
    
    @IBAction func germanPressed(_ sender: UIButton) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
